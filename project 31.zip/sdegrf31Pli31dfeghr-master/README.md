Honey has seen the plinko game played by various contestants on the TV.

Plinko is a game played on a nearly vertical board populated with offset rows of pegs. The player chooses one of five slots in the top of the board, drops the chip into it and watches as the chip bounces down the board. Each time the chip encounters a peg, it will either bounce left or right.

Now Honey wants to make this game for herself so she can play anytime.